package com.c2tc_Placement;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CollegeController {
	
	@Autowired
	private CollegeService cservice;
	
	@GetMapping ("/college")
	
	public List<CollegeEntity> list()
	{
		return cservice.listall();
	}
	
	@GetMapping ("/college/{id}")
	public ResponseEntity<CollegeEntity> get(@PathVariable Integer id)
	{
		try {
			
			CollegeEntity college = cservice.get(id);
			return new ResponseEntity<CollegeEntity>(college,HttpStatus.OK);
			
		} catch (NoSuchElementException e) {
			
			return new ResponseEntity<CollegeEntity>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping ("/college")
	public  ResponseEntity<CollegeEntity> add(@RequestBody CollegeEntity college) 
	{
		try {
			
		    cservice.create(college);
		    return new ResponseEntity<CollegeEntity>(HttpStatus.OK);
		}catch (DuplicateKeyException e) {
			return new ResponseEntity<CollegeEntity>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping ("/college/{id}")
	 public ResponseEntity<?>update(@RequestBody CollegeEntity college,@PathVariable Integer id)
	 {
		try {
			CollegeEntity existsCollege = cservice.get(id);
			 existsCollege.setCadmin(college.getCadmin());
			 existsCollege.setCname(college.getCname());
			 existsCollege.setLocation(college.getLocation());
			cservice.save(existsCollege);
			return new ResponseEntity<>(existsCollege,HttpStatus.OK);
			
		} catch (NoSuchElementException e) {
			
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);

		}
	 }
	
	@DeleteMapping ("/college/{id}")
	public void delete(@PathVariable Integer id)
	{
		cservice.delete(id);
	}
 
}
