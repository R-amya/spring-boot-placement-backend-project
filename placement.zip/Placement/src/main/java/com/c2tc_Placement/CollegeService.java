package com.c2tc_Placement;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class CollegeService {
	
	@Autowired
	private  CollegeRepository crepo;
	public List<CollegeEntity> listall()
	{
		return crepo.findAll();
	}

	public void create(CollegeEntity college)
	{
		if(crepo.existsById(college.getId())) {
			throw new DuplicateKeyException("Duplicate ID found");
		}
		crepo.save(college);
	}
	
	public void save(CollegeEntity college)
	{
		crepo.save(college);
	}
	
	public CollegeEntity get(Integer id)
	{
		return crepo.findById(id).get();
	}
	
	public void delete(Integer id)
	{
		crepo.deleteById(id);
	}
	

}
