package com.c2tc_Placement;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table; 

@Entity
@Table(name="college")
public class CollegeEntity {
	
	private Integer id;
	private String cadmin;
	private String cname;
	private String location;
	
	public CollegeEntity() {
		
	}

	public CollegeEntity(Integer id, String cadmin, String cname, String location) {
		
		this.id = id;
		this.cadmin = cadmin;
		this.cname = cname;
		this.location = location;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCadmin() {
		return cadmin;
	}

	public void setCadmin(String cadmin) {
		this.cadmin = cadmin;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "CollegeEntity [id=" + id + ", cadmin=" + cadmin + ", cname=" + cname + ", location=" + location + "]";
	}
	
	
}
	